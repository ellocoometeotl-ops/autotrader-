# AutoTrader PWA

Proyecto de trading automático con:
- Frontend React + TailwindCSS (PWA responsive)
- Backend Node.js + Express + WebSocket
- Adaptadores para Alpaca, Binance e Interactive Brokers
- Gestión de riesgo con ATR, sizing, stop loss, take profit y trailing stops
- Multi-broker
- Configuración para despliegue en Render.com
